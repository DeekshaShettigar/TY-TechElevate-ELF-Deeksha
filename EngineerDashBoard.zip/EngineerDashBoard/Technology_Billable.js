// Build the chart
Highcharts.chart('Tech_Billable', {
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie'
    },
    title: {
      text: 'Technology Wise Billable Engineers'
    },
    tooltip: {
      pointFormat: '<b>{point.y}</b>'
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: false
        },
        showInLegend: true
      }
    },
    series: [{
     
      colorByPoint: true,
      data: [{
        name: 'Java FullStack',
        y: 25
      }, {
        name: 'MEAN Stack',
        y: 15
      }, {
        name: 'Dot Net',
        y: 20
      }, {
        name: 'Data Science',
        y: 30
      }]
    }]
  });