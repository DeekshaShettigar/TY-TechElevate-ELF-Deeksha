Highcharts.chart('Tech_NonBillable', {
    chart: {
        type: 'pie'
    },
    title: {
        text: 'Technology Wise Non Billable Engineers'
    },
    tooltip: {
        headerFormat: '',
        pointFormat: '<span style="color:{point.color}">\u25CF</span> <b> {point.name}</b><br/>' +
            ' <b>{point.y}</b><br/>' 
         
    },
    series: [{
        minPointSize: 10,
        innerSize: '20%',
        zMin: 0,
        name: 'countries',
        data: [{
            name: 'Java FullStack',
            y: 50
        }, {
            name: 'MEAN Stack',
            y: 42
        }, {
            name: 'Dot net',
            y: 30
        }, {
            name: 'Data Science',
            y: 25
        }]
    }]
});